package com.sunny.utils;

public class Logger {
    private static final String TAG = "flux";

    public static void logError(String message) {

    }
}
